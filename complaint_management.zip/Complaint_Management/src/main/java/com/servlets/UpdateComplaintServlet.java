package com.servlets;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/UpdateComplaintServlet")
public class UpdateComplaintServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String role = (String) request.getSession().getAttribute("role");
        if (!"user".equalsIgnoreCase(role)) {
            response.sendRedirect("index.html");
            return;
        }

        int userId = Integer.parseInt(request.getSession().getAttribute("user_id").toString());
        int complaintId = Integer.parseInt(request.getParameter("cid"));

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/complaintdb", "root", "Suma@#424906");
                 PreparedStatement ps = con.prepareStatement(
                    "SELECT title, description, category, priority FROM complaints WHERE complaint_id=? AND user_id=? AND status='Pending'")) {

                ps.setInt(1, complaintId);
                ps.setInt(2, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        response.setContentType("text/html");
                        response.getWriter().println("<h3>Update Complaint</h3>");
                        response.getWriter().println("<form action='UpdateComplaintServlet' method='post'>");
                        response.getWriter().println("<input type='hidden' name='cid' value='" + complaintId + "'>");
                        response.getWriter().println("Title: <input type='text' name='title' value='" + rs.getString("title") + "' required><br><br>");
                        response.getWriter().println("Description:<br><textarea name='description' rows='4' cols='50' required>" + rs.getString("description") + "</textarea><br><br>");
                        response.getWriter().println("Category: <input type='text' name='category' value='" + rs.getString("category") + "' required><br><br>");
                        response.getWriter().println("Priority: <input type='text' name='priority' value='" + rs.getString("priority") + "' required><br><br>");
                        response.getWriter().println("<input type='submit' value='Update'>");
                        response.getWriter().println("</form>");
                    } else {
                        response.getWriter().println("Complaint not found or cannot be updated.");
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String role = (String) request.getSession().getAttribute("role");
        if (!"user".equalsIgnoreCase(role)) {
            response.sendRedirect("index.html");
            return;
        }

        int userId = Integer.parseInt(request.getSession().getAttribute("user_id").toString());
        int complaintId = Integer.parseInt(request.getParameter("cid"));
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String category = request.getParameter("category");
        String priority = request.getParameter("priority");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/complaintdb", "root", "Suma@#424906");
                 PreparedStatement ps = con.prepareStatement(
                    "UPDATE complaints SET title=?, description=?, category=?, priority=? WHERE complaint_id=? AND user_id=? AND status='Pending'")) {

                ps.setString(1, title);
                ps.setString(2, description);
                ps.setString(3, category);
                ps.setString(4, priority);
                ps.setInt(5, complaintId);
                ps.setInt(6, userId);

                ps.executeUpdate();
            }

            response.sendRedirect("user.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
