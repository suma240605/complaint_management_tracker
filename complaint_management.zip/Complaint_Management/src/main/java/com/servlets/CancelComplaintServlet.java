package com.servlets;
import java.io.IOException;
import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/CancelComplaintServlet")
public class CancelComplaintServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = -4203010762740041709L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || !"user".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.sendRedirect("index.html");
            return;
        }

        int userId = (Integer) session.getAttribute("user_id");
        int complaintId = Integer.parseInt(request.getParameter("cid"));

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/complaintdb", "root", "Suma@#424906");

            // Only allow cancel if complaint belongs to user and status is Pending
            String sql = "UPDATE complaints SET status='Cancelled' WHERE complaint_id=? AND user_id=? AND status='Pending'";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, complaintId);
            ps.setInt(2, userId);

            ps.close();
            con.close();

            response.sendRedirect("user.jsp"); // back to user dashboard
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
