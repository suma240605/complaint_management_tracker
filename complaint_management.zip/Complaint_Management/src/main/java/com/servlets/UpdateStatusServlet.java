package com.servlets;
import java.io.IOException;
import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/UpdateStatusServlet")
public class UpdateStatusServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 972804683294735990L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equalsIgnoreCase((String) session.getAttribute("role"))) {
            response.sendRedirect("index.html");
            return;
        }

        int complaintId = Integer.parseInt(request.getParameter("cid"));
        String status = request.getParameter("status");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/complaintdb", "root", "Suma@#424906");
                 PreparedStatement ps = con.prepareStatement(
                     "UPDATE complaints SET status=? WHERE complaint_id=?")) {

                ps.setString(1, status);
                ps.setInt(2, complaintId);
                ps.executeUpdate();
            }

            response.sendRedirect("admin.jsp"); // back to dashboard

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
